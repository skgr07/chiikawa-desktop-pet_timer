@echo off
cd /d "%~dp0"
where pyw >nul 2>nul
if not errorlevel 1 (
    start "" pyw "%~dp0chiikawa_timer.py"
    exit /b 0
)
where pythonw >nul 2>nul
if not errorlevel 1 (
    start "" pythonw "%~dp0chiikawa_timer.py"
    exit /b 0
)
echo Python is required. Install Python, then run:
echo py -m pip install -r requirements.txt
pause
exit /b 1
