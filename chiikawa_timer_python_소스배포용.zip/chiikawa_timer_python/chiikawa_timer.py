"""Chiikawa desktop timer. Run with Python 3.10+ and PySide6."""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
import math
import os
from pathlib import Path
import sys
import time

from PySide6.QtCore import QCoreApplication, QEvent, QPoint, QPointF, QRectF, QSize, Qt, QTimer, QUrl
from PySide6.QtGui import QColor, QCursor, QFont, QFontDatabase, QIcon, QIntValidator, QPainter, QPainterPath, QPen, QPixmap
from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
from PySide6.QtWidgets import (QApplication, QDialog, QFrame, QGraphicsDropShadowEffect,
    QHBoxLayout, QLabel, QLineEdit, QMenu, QMessageBox, QPushButton,
    QSystemTrayIcon, QVBoxLayout, QWidget)

ROOT = Path(__file__).resolve().parent
ASSETS = ROOT / 'assets'
NAMES = {'chiikawa': '치이카와', 'hachiware': '하치와레', 'usagi': '우사기'}
SONG_SECONDS = {'chiikawa': 27, 'hachiware': 57, 'usagi': 16}
CENTER = QPointF(190, 190)
RADIUS = 103
STUDY_OFFSET = QPointF(-10, -9.0909423828125)
FINISH_OFFSET = QPointF(0, -12)
TIME_OFFSET = QPointF(11, -15)


@dataclass
class Countdown:
    duration: float = 900
    remaining: float = 900
    state: str = 'ready'
    deadline: float = 0
    finished_at: float = 0

    def start(self, seconds: float, now: float):
        if not math.isfinite(seconds) or not 1 <= seconds <= 10800:
            raise ValueError('Timer duration must be 1–10800 seconds')
        self.duration = self.remaining = seconds
        self.deadline = now + seconds
        self.state = 'running'
        self.finished_at = 0

    def tick(self, now: float) -> bool:
        if self.state == 'running':
            self.remaining = max(0, self.deadline - now)
            if self.remaining == 0:
                self.state = 'finished'
                self.finished_at = now
                return True
        return False

    def pause_resume(self, now: float) -> bool:
        completed = self.tick(now)
        if self.state == 'running':
            self.state = 'paused'
        elif self.state == 'paused':
            self.deadline = now + self.remaining
            self.state = 'running'
        return completed

    def stop(self):
        self.state = 'ready'
        self.remaining = self.duration
        self.finished_at = 0

    @property
    def progress(self):
        return max(0, min(1, 1 - self.remaining / self.duration))

    def fade(self, now):
        if self.state == 'ready':
            return 0
        return max(0, 1 - (now - self.finished_at) / 1.8) if self.state == 'finished' else 1


def blend(a, b, fraction):
    a, b = QColor(a), QColor(b)
    return QColor(*(round(x + (y-x)*fraction) for x, y in zip(a.getRgb()[:3], b.getRgb()[:3])))


def urgency(fraction):
    return blend('#8dcfa8', '#eeb45b', fraction/.55) if fraction < .55 else blend('#eeb45b', '#e6454a', (fraction-.55)/.45)


def orbit(fraction, offset=0):
    angle = -math.pi/2 + fraction*math.tau + offset
    return CENTER + QPointF(math.cos(angle)*RADIUS, math.sin(angle)*RADIUS)


def sprite_frame(elapsed, row):
    holds = [140, 140, 140, 280] if row == 3 else [140, 140, 140, 140, 280]
    offset = elapsed*1000 % sum(holds)
    for i, hold in enumerate(holds):
        if offset < hold:
            return i
        offset -= hold
    return 0


class Popup(QWidget):
    """A compact, non-modal settings panel anchored to the cursor."""
    def __init__(self, owner, anchor, heading=None):
        super().__init__(owner, Qt.WindowType.Popup | Qt.WindowType.FramelessWindowHint | Qt.WindowType.NoDropShadowWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.anchor = QPoint(anchor)
        # One painted rounded card; no native window frame or second shadow panel.
        self.setObjectName('popupWindow')
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        self.card = QWidget()
        self.card.setObjectName('contextMenu')
        outer.addWidget(self.card)
        self.setStyleSheet('''QWidget#popupWindow, QWidget#contextMenu { background:transparent; border:0; }
            QPushButton { color:#343b43; background:transparent; border:0; border-radius:6px;
                padding:6px; font-size:12px; font-weight:normal; text-align:left; }
            QPushButton:hover { background:#e9f1ea; }
            QPushButton[selected="true"] { background:#e9f1ea; font-weight:700; }
            QLabel#menuTitle { color:#8a938d; font-size:10px; background:transparent; border:0; }
            QFrame#separator { background:#eaece8; border:0; }''')
        self.column = QVBoxLayout(self.card)
        self.column.setContentsMargins(6, 6, 6, 6)
        self.column.setSpacing(0)
        if heading:
            title = QLabel(heading)
            title.setObjectName('menuTitle')
            title.setContentsMargins(6, 5, 6, 5)
            self.column.addWidget(title)
        self.setFixedWidth(120)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setPen(QPen(QColor('#dededb'), 1))
        painter.setBrush(QColor(255, 255, 255, 245))
        painter.drawRoundedRect(QRectF(self.rect()).adjusted(.5, .5, -.5, -.5), 9, 9)

    def button(self, text, callback, close=True):
        button = QPushButton(text)
        button.setFixedHeight(28)
        button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.column.addWidget(button)
        def clicked():
            if close:
                self.hide()
            callback()
        button.clicked.connect(clicked)
        return button

    def separator(self):
        row = QWidget()
        layout = QVBoxLayout(row)
        layout.setContentsMargins(4, 5, 4, 5)
        line = QFrame()
        line.setObjectName('separator')
        line.setFixedHeight(1)
        layout.addWidget(line)
        self.column.addWidget(row)

    def display(self):
        self.adjustSize()
        area = (QApplication.screenAt(self.anchor) or QApplication.primaryScreen()).availableGeometry()
        self.move(max(area.left(), min(self.anchor.x(), area.right()-self.width()+1)),
                  max(area.top(), min(self.anchor.y(), area.bottom()-self.height()+1)))
        if getattr(self, 'wait_for_dialog_close', False):
            QTimer.singleShot(30, self.show)
        else:
            self.show()


class TimerPet(QWidget):
    def __init__(self, *, persist=True, clock=time.monotonic):
        super().__init__()
        self.clock = clock
        self.model = Countdown()
        self.persist = persist
        self.settings_path = Path(os.getenv('APPDATA', str(Path.home()))) / 'chiikawa_timer_python' / 'settings.json'
        self.character = 'usagi'
        self.sound = self.show_siren = self.on_top = self.reminders = True
        self.font_family = 'Segoe UI'
        for name in ['Pretendard-Regular.otf', 'Pretendard-Bold.otf']:
            font_id = QFontDatabase.addApplicationFont(str(ASSETS/name))
            if font_id >= 0:
                self.font_family = QFontDatabase.applicationFontFamilies(font_id)[0]
        self.setFont(self.font(12))
        self.study = {key: [self.load_pixmap(f'{key}/study-{i}.png') for i in range(1, 4)] for key in NAMES}
        self.study_icons = {key: [self.make_study_icon(frame) for frame in frames]
                            for key, frames in self.study.items()}
        self.icon_frame = -1
        self.sheets = {key: self.load_pixmap(f'{key}/spritesheet.png') for key in NAMES}
        self.siren = self.load_pixmap('siren.png')
        self.mermaid = self.load_pixmap('mermaid.png')
        self.scaled_images = {}
        for key in NAMES:
            if not (ASSETS/f'{key}-complete.flac').is_file():
                raise FileNotFoundError(f'Missing completion song: {key}')
        self.player = QMediaPlayer(self)
        self.audio = QAudioOutput(self)
        self.audio.setVolume(1.0)  # Lossless FLAC tracks already normalized to the same -18 LUFS.
        self.player.setAudioOutput(self.audio)
        self.player.errorOccurred.connect(self.audio_error)
        self.audio_error_text = ''
        self.popup = None
        self.drag_offset = None
        self.custom_dialog = None
        self.started_at = self.clock()
        self.last_reminder = self.started_at
        self.toast_until = 0
        self.finish_duration = SONG_SECONDS[self.character]
        saved_position = self.load_settings() if persist else None
        self.setWindowFlags(Qt.WindowType.Tool | Qt.WindowType.FramelessWindowHint |
                            (Qt.WindowType.WindowStaysOnTopHint if self.on_top else Qt.WindowType.Widget))
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setFixedSize(380, 380)
        self.setWindowTitle('치이카와 타이머 3종 · Python')
        self.setWindowIcon(self.study_icons[self.character][0])
        self.dock()
        if saved_position:
            self.restore_position(QPoint(*saved_position))
        self.tray = None
        if QSystemTrayIcon.isSystemTrayAvailable():
            self.tray = QSystemTrayIcon(self.windowIcon(), self)
            self.tray.setToolTip('치이카와 타이머 3종')
            menu = QMenu(self)
            menu.addAction('설정', lambda: self.show_home(self.pos()+QPoint(190, 190)))
            menu.addAction('오른쪽 아래로 이동', self.dock)
            menu.addAction('종료', self.close)
            self.tray.setContextMenu(menu)
            self.tray.activated.connect(lambda reason: self.show_home(self.pos()+QPoint(190, 190)) if reason == QSystemTrayIcon.ActivationReason.Trigger else None)
            self.tray.show()
        self.animation = QTimer(self)
        self.animation.setTimerType(Qt.TimerType.PreciseTimer)
        self.animation.timeout.connect(self.tick)
        self.animation.start(16)

    def font(self, pixels, bold=False):
        font = QFont(self.font_family)
        font.setPixelSize(pixels)
        font.setBold(bold)
        return font

    @staticmethod
    def load_pixmap(name):
        result = QPixmap(str(ASSETS/name))
        if result.isNull():
            raise FileNotFoundError(f'Missing or invalid image: {ASSETS/name}')
        return result

    @staticmethod
    def make_study_icon(frame):
        icon = QPixmap(32, 32)
        icon.fill(Qt.GlobalColor.transparent)
        scaled = frame.scaled(30, 30, Qt.AspectRatioMode.KeepAspectRatio,
                              Qt.TransformationMode.SmoothTransformation)
        painter = QPainter(icon)
        painter.drawPixmap((32-scaled.width())//2, (32-scaled.height())//2, scaled)
        painter.end()
        return QIcon(icon)

    def update_study_icon(self, now):
        frame = int((now-self.started_at)*3)%3
        if frame != self.icon_frame:
            self.icon_frame = frame
            icon = self.study_icons[self.character][frame]
            self.setWindowIcon(icon)
            if self.tray:
                self.tray.setIcon(icon)
                self.tray.setToolTip(NAMES[self.character]+' · 치이카와 타이머')

    def load_settings(self):
        try:
            data = json.loads(self.settings_path.read_text(encoding='utf-8'))
            if data.get('character') in NAMES:
                self.character = data['character']
            for key in ['sound', 'show_siren', 'on_top', 'reminders']:
                if isinstance(data.get(key), bool):
                    setattr(self, key, data[key])
            seconds = data.get('duration', 900)
            if isinstance(seconds, (int, float)) and math.isfinite(seconds) and 1 <= seconds <= 10800:
                self.model.duration = self.model.remaining = seconds
            pos = data.get('position')
            if isinstance(pos, list) and len(pos) == 2 and all(isinstance(x, int) for x in pos):
                return pos
        except (OSError, ValueError, TypeError):
            pass
        return None

    def save_settings(self):
        if not self.persist:
            return
        data = {key: getattr(self, key) for key in ['character', 'sound', 'show_siren', 'on_top', 'reminders']}
        data.update(duration=self.model.duration, position=[self.x(), self.y()])
        try:
            self.settings_path.parent.mkdir(parents=True, exist_ok=True)
            temporary = self.settings_path.with_suffix('.tmp')
            temporary.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
            temporary.replace(self.settings_path)
        except OSError as error:
            print(f'Cannot save preferences: {error}', file=sys.stderr)

    def restore_position(self, point):
        screen = QApplication.screenAt(point+QPoint(190, 190)) or QApplication.primaryScreen()
        area = screen.availableGeometry()
        self.move(max(area.left()-80, min(point.x(), area.right()-300)),
                  max(area.top()-80, min(point.y(), area.bottom()-300)))

    def dock(self):
        screen = self.screen() or QApplication.primaryScreen()
        area = screen.availableGeometry()
        target = QPoint(1567-190, 724-190)
        self.move(max(area.left(), min(target.x(), area.right()-379)),
                  max(area.top(), min(target.y(), area.bottom()-379)))

    def begin(self, seconds):
        self.player.stop()
        self.model.start(seconds, self.clock())
        self.save_settings()
        self.update()

    def stop(self):
        self.player.stop()
        self.model.stop()
        self.update()

    def pause_resume(self):
        if self.model.pause_resume(self.clock()):
            self.complete()
        self.update()

    def complete(self):
        self.finish_duration = SONG_SECONDS[self.character]
        self.player.stop()
        self.player.setSource(QUrl.fromLocalFile(str(ASSETS/f'{self.character}-complete.flac')))
        if self.sound:
            self.player.play()

    def tick(self):
        now = self.clock()
        self.update_study_icon(now)
        if self.model.tick(now):
            self.complete()
        if (self.model.state == 'finished' and now-self.model.finished_at >= self.finish_duration
                and self.player.playbackState() != QMediaPlayer.PlaybackState.StoppedState):
            self.player.stop()
        if self.reminders and now-self.last_reminder >= 900:
            self.last_reminder = now
            self.toast_until = now+6
        self.update()

    def audio_error(self, error, message):
        self.audio_error_text = message
        print(f'Audio playback error: {message}', file=sys.stderr)
        if self.tray:
            self.tray.showMessage('완료 음악을 재생하지 못했어요', message)

    def image(self, painter, pixmap, center, side, flip=False, alpha=1):
        size = pixmap.size()
        factor = side/max(size.width(), size.height())
        width, height = size.width()*factor, size.height()*factor
        # Pre-filter large PNGs once at the monitor's actual pixel density;
        # drawing a 1536px image directly at 64px can make fine outlines flicker.
        density = self.devicePixelRatioF()
        key = (pixmap.cacheKey(), side, density)
        if key not in self.scaled_images:
            self.scaled_images[key] = pixmap.scaled(
                QSize(max(1, round(width*density)), max(1, round(height*density))),
                Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
        pixmap = self.scaled_images[key]
        painter.save()
        painter.setOpacity(alpha)
        painter.translate(center)
        if flip:
            painter.scale(-1, 1)
        painter.drawPixmap(QRectF(-width/2, -height/2, width, height), pixmap, QRectF(pixmap.rect()))
        painter.restore()

    def paintEvent(self, event):
        now = self.clock()
        p = QPainter(self)
        p.setRenderHints(QPainter.RenderHint.Antialiasing | QPainter.RenderHint.SmoothPixmapTransform)
        fade, progress = self.model.fade(now), self.model.progress
        finished = self.model.state == 'finished'
        if fade > 0:
            p.save()
            p.setOpacity(fade)
            track = blend('#e5e9e7', '#f7d3d7', progress)
            p.setPen(QPen(track, 9, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
            p.drawEllipse(CENTER, RADIUS, RADIUS)
            if progress > 0:
                path = QPainterPath()
                path.moveTo(orbit(0))
                for i in range(1, 129):
                    path.lineTo(orbit(progress*i/128))
                p.setPen(QPen(urgency(progress), 9, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
                p.drawPath(path)
            count = math.ceil(self.model.remaining)
            value = f'{count//60:02}:{count%60:02}'
            p.setFont(self.font(19, True))
            p.setPen(blend('#343b43', '#cf3342', progress))
            anchor = CENTER+STUDY_OFFSET+TIME_OFFSET+QPointF(0, 103)
            p.drawText(anchor-QPointF(p.fontMetrics().horizontalAdvance(value)/2, 0), value)
            p.restore()
            if self.show_siren:
                spacing = max(.48, 2*math.asin(58/(2*RADIUS)))
                pair = 2*math.asin(34/(2*RADIUS))
                for i, offset in enumerate([0, spacing, spacing+pair]):
                    pos = orbit(progress, -offset)
                    if finished:
                        pos.setX(pos.x()-(1-fade)*108)
                    angle = -math.pi/2+progress*math.tau-offset
                    self.image(p, self.siren if i == 0 else self.mermaid, pos,
                               64 if i == 0 else 40, math.sin(angle)>0 or finished, fade)
        elapsed = now-self.model.finished_at
        if finished and elapsed < self.finish_duration:
            row = 4 if int(elapsed*2)%2 == 0 else 3
            frame = sprite_frame(elapsed, row)
            width = 165 if self.character == 'usagi' else 132
            height = width*208/192
            pos = CENTER+FINISH_OFFSET-QPointF(width/2, height/2+abs(math.sin(elapsed*7))*12)
            p.drawPixmap(QRectF(pos.x(), pos.y(), width, height), self.sheets[self.character], QRectF(frame*192, row*208, 192, 208))
            p.setPen(Qt.PenStyle.NoPen)
            for i in range(20):
                fraction = (elapsed*.65+i*.137)%1
                p.setBrush(QColor(['#f2bd6f', '#99bdfa', '#eaa1ba', '#a1d4b4'][i%4]))
                p.drawRect(QRectF(100+(i*41)%180+math.sin(fraction*8+i)*8, 65+fraction*230, 3, 5))
            p.setFont(self.font(18))
            p.setPen(QColor('#e9b758')); p.drawText(QPointF(90, 140), '♪')
            p.setPen(QColor('#8db5f2')); p.drawText(QPointF(270, 115), '♫')
        else:
            frame = int((now-self.started_at)*3)%3
            self.image(p, self.study[self.character][frame], CENTER+STUDY_OFFSET+QPointF(2.49, -4.98), 165)
        if now < self.toast_until:
            p.setPen(Qt.PenStyle.NoPen); p.setBrush(QColor('#fff8df'))
            p.drawRoundedRect(QRectF(45, 350, 290, 25), 10, 10)
            p.setFont(self.font(10)); p.setPen(QColor('#626057'))
            p.drawText(QRectF(45, 350, 290, 25), Qt.AlignmentFlag.AlignCenter, '물 마시고 잠깐 스트레칭해요!')

    def interactive(self, point):
        if self.clock() < self.toast_until and QRectF(45, 350, 290, 25).contains(point):
            return True
        if self.model.state in ['running', 'paused'] or (self.model.state == 'finished' and self.model.fade(self.clock()) > 0):
            return math.hypot(point.x()-190, point.y()-190) <= 176
        pos = CENTER+(FINISH_OFFSET if self.model.state == 'finished' and self.clock()-self.model.finished_at < self.finish_duration else STUDY_OFFSET)
        return QRectF(pos.x()-89, pos.y()-105, 178, 210).contains(point)

    def nativeEvent(self, event_type, message):
        if sys.platform == 'win32':
            import ctypes
            from ctypes import wintypes
            msg = wintypes.MSG.from_address(int(message))
            if msg.message == 0x84:  # WM_NCHITTEST: let empty desktop area receive input.
                # Qt's global cursor coordinates account for per-monitor DPI.
                if not self.interactive(self.mapFromGlobal(QCursor.pos())):
                    return True, -1  # HTTRANSPARENT
        return super().nativeEvent(event_type, message)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton and self.interactive(event.position()):
            self.drag_offset = event.globalPosition().toPoint()-self.pos()
            event.accept()

    def mouseMoveEvent(self, event):
        if self.drag_offset is not None:
            self.move(event.globalPosition().toPoint()-self.drag_offset)

    def mouseReleaseEvent(self, event):
        if self.drag_offset is not None:
            self.drag_offset = None
            self.save_settings()

    def contextMenuEvent(self, event):
        if self.interactive(event.pos()):
            self.show_home(event.globalPos()+QPoint(8, 0))

    def dismiss_settings(self):
        popup, dialog = self.popup, self.custom_dialog
        self.popup = self.custom_dialog = None
        if popup:
            popup.close()
            popup.deleteLater()
        if dialog:
            dialog.reject()
            # Dispose the old native dialog before activating its replacement.
            # Otherwise its delayed destruction can dismiss the new Qt popup.
            QCoreApplication.sendPostedEvents(dialog, QEvent.Type.DeferredDelete)

    def make_popup(self, anchor, title=None):
        replacing_dialog = self.custom_dialog is not None
        self.dismiss_settings()
        self.popup = Popup(self, anchor, title)
        self.popup.wait_for_dialog_close = replacing_dialog
        return self.popup

    def show_home(self, anchor):
        panel = self.make_popup(anchor)
        panel.button('타이머 설정', lambda: self.show_timer(anchor))
        panel.button('캐릭터 설정', lambda: self.show_characters(anchor))
        panel.display()

    def show_timer(self, anchor):
        panel = self.make_popup(anchor, '타이머 설정')
        running = self.model.state in ['running', 'paused']
        if running:
            panel.button('일시정지' if self.model.state == 'running' else '계속하기', self.pause_resume)
            panel.button('타이머 해제', self.stop)
        else:
            for minutes in [15, 30, 60]:
                panel.button(f'{minutes}분', lambda minutes=minutes: self.begin(minutes*60))
            panel.button('커스텀', self.show_custom)
        panel.separator()
        for attr, label in [('show_siren', '세이렌 표시'), ('sound', '완료 노래')]:
            button = panel.button(('✓ ' if getattr(self, attr) else '')+label, lambda: None, close=False)
            button.clicked.connect(lambda checked=False, attr=attr, label=label, button=button: self.toggle_option(attr, label, button))
        if not running:
            panel.button('종료', self.close)
        panel.display()

    def toggle_option(self, attr, label, button):
        setattr(self, attr, not getattr(self, attr))
        button.setText(('✓ ' if getattr(self, attr) else '')+label)
        if attr == 'sound' and not self.sound:
            self.player.stop()
        self.save_settings()
        self.update()

    def show_characters(self, anchor):
        panel = self.make_popup(anchor)
        for key, name in NAMES.items():
            button = panel.button(name, lambda key=key: self.select_character(key))
            button.setProperty('selected', key == self.character)
            button.style().unpolish(button)
            button.style().polish(button)
        panel.display()

    def select_character(self, key):
        self.character = key
        self.icon_frame = -1
        self.update_study_icon(self.clock())
        if self.model.state == 'finished':
            self.stop()
        self.save_settings()
        self.update()

    def show_custom(self):
        self.dismiss_settings()
        dialog = QDialog(self, Qt.WindowType.Dialog | Qt.WindowType.FramelessWindowHint)
        self.custom_dialog = dialog
        dialog.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        dialog.setWindowTitle('커스텀 타이머')
        dialog.setFixedWidth(232)
        outer = QVBoxLayout(dialog)
        outer.setContentsMargins(16, 16, 16, 24)
        card = QFrame()
        card.setObjectName('customDialog')
        outer.addWidget(card)
        shadow = QGraphicsDropShadowEffect(card)
        shadow.setBlurRadius(24)
        shadow.setOffset(0, 8)
        shadow.setColor(QColor(0, 0, 0, 34))
        card.setGraphicsEffect(shadow)
        dialog.setStyleSheet('''QFrame#customDialog {background:white; border:0; border-radius:12px;}
            QLabel {color:#8a938d; background:transparent; font-size:12px;}
            QLabel#customTitle {color:#343b43; font-size:13px; font-weight:normal;}
            QLineEdit {color:#343b43; background:white; border:1px solid #e3e8e2;
                border-radius:6px; font-size:18px; padding:8px;}
            QLineEdit:focus {border-color:#929b95;}
            QPushButton {background:#f0f2ef; color:#343b43; border:0;
                border-radius:8px; font-size:12px; padding:7px 12px;}
            QPushButton#startButton {background:#343b43; color:white;}''')
        column = QVBoxLayout(card)
        column.setContentsMargins(14, 14, 14, 14)
        column.setSpacing(12)
        title = QLabel('커스텀 타이머')
        title.setObjectName('customTitle')
        column.addWidget(title)
        row = QHBoxLayout()
        row.setSpacing(8)
        spin = QLineEdit()
        spin.setObjectName('minutes')
        spin.setValidator(QIntValidator(1, 180, spin))
        spin.setMinimumHeight(42)
        spin.setText(str(max(1, math.ceil(self.model.duration/60))))
        spin.setMinimumWidth(0)
        row.addWidget(spin, 1)
        row.addWidget(QLabel('분'))
        column.addLayout(row)
        footer = QHBoxLayout()
        footer.setSpacing(6)
        footer.addStretch()
        cancel, start = QPushButton('취소'), QPushButton('시작')
        start.setObjectName('startButton')
        for button in [cancel, start]:
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            footer.addWidget(button)
        def submit():
            if spin.hasAcceptableInput():
                self.begin(int(spin.text())*60)
                dialog.accept()
            else:
                spin.setFocus()
                spin.setToolTip('1~180분을 입력하세요.')
        start.clicked.connect(submit)
        spin.returnPressed.connect(submit)
        cancel.clicked.connect(dialog.reject)
        def clear_dialog():
            if self.custom_dialog is dialog:
                self.custom_dialog = None
        dialog.finished.connect(clear_dialog)
        column.addLayout(footer)
        dialog.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        dialog.adjustSize()
        area = self.screen().availableGeometry()
        dialog.move(area.center()-dialog.rect().center())
        dialog.show()
        spin.setFocus(); spin.selectAll()

    def closeEvent(self, event):
        self.animation.stop()
        self.player.stop()
        self.save_settings()
        self.dismiss_settings()
        if self.tray:
            self.tray.hide()
        event.accept()
        if self.persist:
            QApplication.quit()


def main():
    parser = argparse.ArgumentParser(description='치이카와 타이머 3종 · Python + PySide6')
    parser.add_argument('--demo', action='store_true', help='Start a 12-second timer')
    parser.add_argument('--character', choices=NAMES)
    args = parser.parse_args()
    app = QApplication(sys.argv[:1])
    # The pet is a Qt.Tool window and does not count as a primary window.
    # Closing the custom timer dialog must not quit the desktop pet.
    # TimerPet.closeEvent handles explicit exits from the menu and tray.
    app.setQuitOnLastWindowClosed(False)
    try:
        pet = TimerPet()
    except (FileNotFoundError, RuntimeError) as error:
        QMessageBox.critical(None, '실행 파일 확인', str(error))
        return 1
    if args.character:
        pet.select_character(args.character)
    pet.show()
    if args.demo:
        pet.begin(12)
    return app.exec()


if __name__ == '__main__':
    raise SystemExit(main())
