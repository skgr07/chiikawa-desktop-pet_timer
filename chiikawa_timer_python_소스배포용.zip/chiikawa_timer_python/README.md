# 치이카와 타이머 3종 · Python

Python + PySide6로 구현한 투명 데스크톱 펫 타이머입니다. Python 소스 그대로 실행합니다.

## 설치와 실행

Windows 64비트용 Python 3.10 이상을 [공식 사이트](https://www.python.org/downloads/windows/)에서 설치하세요. 이 버전은 Python 3.12에서 검증했습니다.

이 폴더에서 터미널을 열고 실행합니다.

```powershell
py -m pip install -r requirements.txt
py chiikawa_timer.py
```

설치 후에는 `실행.bat`을 더블클릭해도 됩니다. 검은 창은 바로 닫히고 타이머는 별도로 계속 실행됩니다. `assets`와 코드 파일은 함께 두세요.

## 사용법

- 캐릭터를 드래그하면 원과 시간도 같은 비율을 유지하며 움직입니다.
- 우클릭하면 커서 오른쪽에 타이머 설정 / 캐릭터 설정이 나옵니다.
- 타이머: 15분 / 30분 / 60분 / 커스텀 1~180분. 선택하면 바로 시작합니다.
- 실행 중 타이머 설정: 일시정지(계속하기), 타이머 해제, 세이렌 표시, 완료 노래만 표시합니다.
- 캐릭터: 치이카와 / 하치와레 / 우사기 순서로 선택합니다.
- 대기 중 타이머 설정 → 종료: 프로그램을 바로 종료합니다.
- 타이머 실행 중에도 Windows 알림 영역 아이콘의 종료 메뉴로 끝낼 수 있습니다.
- 알림 영역 아이콘은 선택한 캐릭터의 공부 모션 3프레임으로 움직입니다.
- 완료하면 1.8초 동안 원·시간·세이렌·인어가 함께 사라지고 캐릭터가 점프와 색종이로 축하합니다.
- 완료 공연은 치이카와 27초 / 하치와레 57초 / 우사기 16초이며, 음악을 꺼도 모션은 같은 시간 동안 재생합니다.
- 프로그램 설정과 위치는 `%APPDATA%\chiikawa_timer_python\settings.json`에 저장합니다. 재실행 시 진행 중 타이머는 복원하지 않습니다.

## 시연

```powershell
py chiikawa_timer.py --demo --character usagi
py chiikawa_timer.py --demo --character chiikawa
py chiikawa_timer.py --demo --character hachiware
```

## 소스 구성

프로그램 로직은 `chiikawa_timer.py` 한 파일입니다. 이미지·음악·폰트는 `assets`에 있습니다.
인터넷 요청, 관리자 권한, 보안 정책 변경을 사용하지 않습니다. 최초 라이브러리 설치에는 인터넷이 필요합니다.
Python 및 Qt 라이브러리에도 PC의 실행 정책이 적용되므로 모든 환경에서 경고 없이 실행되는 것은 보장하지 않습니다.

공부 프레임·완료 스프라이트와, 음량을 정규화한 무손실 FLAC 음악을 사용합니다.
개인 팬 제작·수정본이며 공식 제품이 아닙니다. 자료 출처 및 라이선스는 동봉 문서를 확인하세요.

PySide6는 Qt for Python이며 LGPLv3/GPLv3/상용 라이선스 조건으로 제공됩니다. 필요한 라이브러리는 사용자 환경에 별도 설치합니다.
https://doc.qt.io/qtforpython-6/licenses.html
