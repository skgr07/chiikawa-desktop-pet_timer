"""Functional checks for countdown timing, Qt menus, transparency and local audio."""
import math
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest

from PySide6.QtCore import QPoint, QPointF, Qt, QUrl
from PySide6.QtGui import QImage, QPainter
from PySide6.QtMultimedia import QMediaPlayer
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QPushButton, QLineEdit
from shiboken6 import isValid

from chiikawa_timer import ASSETS, Countdown, NAMES, SONG_SECONDS, TimerPet, orbit

APP = QApplication.instance() or QApplication([])


class FakeClock:
    now = 100.0
    def __call__(self): return self.now


class TimerTests(unittest.TestCase):
    def setUp(self):
        self.clock = FakeClock()
        self.pet = TimerPet(persist=False, clock=self.clock)
        self.pet.sound = False
        self.pet.animation.stop()
        self.pet.move(40, 40)
        self.pet.show()
        APP.processEvents()

    def tearDown(self):
        self.pet.close()
        self.pet.deleteLater()
        APP.processEvents()

    def buttons(self):
        return self.pet.popup.findChildren(QPushButton)

    def texts(self):
        return [b.text() for b in self.buttons()]

    def capture(self, name):
        out=Path(__file__).parent/'verification'
        out.mkdir(exist_ok=True)
        image=QImage(380,380,QImage.Format.Format_ARGB32)
        image.fill(Qt.GlobalColor.transparent)
        p=QPainter(image)
        self.pet.render(p, QPoint())
        p.end()
        self.assertEqual(image.pixelColor(0,0).alpha(),0)
        image.save(str(out/(name+'.png')))
        return image

    def test_deadline_pause_and_delayed_tick(self):
        timer=Countdown()
        timer.start(12,100)
        timer.tick(103.25)
        self.assertAlmostEqual(timer.remaining,8.75)
        timer.pause_resume(104)
        timer.tick(500)
        self.assertEqual(timer.remaining,8)
        self.assertEqual(timer.state,'paused')
        timer.pause_resume(500)
        self.assertTrue(timer.tick(509))
        self.assertEqual(timer.remaining,0)
        self.assertFalse(timer.tick(510))
        self.assertAlmostEqual(timer.fade(509.9),.5)
        self.assertEqual(timer.fade(510.8),0)
        timer.stop()
        self.assertEqual(timer.state,'ready')

    def test_menu_presets_and_running_only_four_buttons(self):
        anchor=QPoint(450,80)
        self.pet.show_home(anchor)
        self.assertEqual(self.texts(),['타이머 설정','캐릭터 설정'])
        QTest.mouseClick(self.buttons()[0],Qt.MouseButton.LeftButton)
        APP.processEvents()
        self.assertEqual(self.texts()[:4],['15분','30분','60분','커스텀'])
        self.assertEqual(self.texts()[-1],'종료')
        QTest.mouseClick(self.buttons()[1],Qt.MouseButton.LeftButton)
        self.assertEqual(self.pet.model.duration,1800)
        self.assertEqual(self.pet.model.state,'running')
        self.pet.show_timer(anchor)
        self.assertEqual(self.texts(),['일시정지','타이머 해제','✓ 세이렌 표시','완료 노래'])
        QTest.mouseClick(self.buttons()[0],Qt.MouseButton.LeftButton)
        self.assertEqual(self.pet.model.state,'paused')
        self.pet.show_timer(anchor)
        self.assertEqual(self.texts()[0],'계속하기')
        QTest.mouseClick(self.buttons()[2],Qt.MouseButton.LeftButton)
        self.assertFalse(self.pet.show_siren)
        self.assertTrue(self.pet.popup.isVisible())
        QTest.mouseClick(self.buttons()[1],Qt.MouseButton.LeftButton)
        self.assertEqual(self.pet.model.state,'ready')

    def test_custom_minutes_and_character_order(self):
        self.pet.show_custom()
        spin=self.pet.custom_dialog.findChild(QLineEdit)
        self.assertEqual((spin.validator().bottom(),spin.validator().top()),(1,180))
        spin.setText('2')
        start=next(b for b in self.pet.custom_dialog.findChildren(QPushButton) if b.text()=='시작')
        QTest.mouseClick(start,Qt.MouseButton.LeftButton)
        APP.processEvents()
        self.assertEqual(self.pet.model.duration,120)
        self.assertEqual(self.pet.model.state,'running')
        self.pet.show_characters(QPoint(450,80))
        self.assertEqual(self.texts(),['치이카와','하치와레','우사기'])
        QTest.mouseClick(self.buttons()[0],Qt.MouseButton.LeftButton)
        self.assertEqual(self.pet.character,'chiikawa')
        self.assertEqual(self.pet.model.state,'running')

    def test_custom_dialog_does_not_quit_main_event_loop(self):
        # A real app.exec() is required: processEvents() alone does not process
        # Qt's automatic quit when the last primary dialog closes.
        for action in ['start', 'cancel']:
            with self.subTest(action=action):
                script = '''
import sys
from PySide6.QtCore import QTimer, Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QPushButton
import chiikawa_timer as timer
real_application = QApplication
sys.argv = ['chiikawa_timer.py']
def application(args):
    app = real_application(args)
    timer.QApplication = real_application
    def exercise():
        pet = next(w for w in app.topLevelWidgets() if isinstance(w, timer.TimerPet))
        pet.persist = False
        pet.sound = False
        pet.show_custom()
        if ACTION == 'start':
            QTest.mouseClick(pet.custom_dialog.findChild(QPushButton, 'startButton'), Qt.MouseButton.LeftButton)
        else:
            pet.custom_dialog.reject()
        def verify():
            assert pet.isVisible()
            assert pet.model.state == ('running' if ACTION == 'start' else 'ready')
            print('PET_STILL_RUNNING', flush=True)
            app.quit()
        QTimer.singleShot(250, verify)
    QTimer.singleShot(50, exercise)
    QTimer.singleShot(2000, app.quit)
    return app
timer.QApplication = application
raise SystemExit(timer.main())
'''.replace('ACTION', repr(action))
                result = subprocess.run([sys.executable, '-c', script],
                    cwd=Path(__file__).parent, capture_output=True, text=True, timeout=10)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertIn('PET_STILL_RUNNING', result.stdout, result.stderr)

    def test_settings_windows_replace_each_other(self):
        anchor=QPoint(450,80)
        self.pet.show_home(anchor)
        home=self.pet.popup
        self.pet.show_timer(anchor)
        self.assertFalse(home.isVisible())
        timer=self.pet.popup
        self.pet.show_custom()
        self.assertFalse(timer.isVisible())
        first=self.pet.custom_dialog
        self.pet.show_custom()
        self.assertTrue(not isValid(first) or not first.isVisible())
        second=self.pet.custom_dialog
        self.pet.show_home(anchor)
        self.assertTrue(not isValid(second) or not second.isVisible())
        self.assertIsNone(self.pet.custom_dialog)
        QTest.qWait(80)
        visible=[widget for widget in QApplication.topLevelWidgets() if isValid(widget) and widget.isVisible() and widget is not self.pet]
        self.assertEqual(visible,[self.pet.popup])

    def test_each_character_completion_and_transparency(self):
        for key in NAMES:
            self.pet.select_character(key)
            self.pet.stop()
            self.clock.now=100
            self.pet.started_at=100
            self.capture(key+'-study')
            self.pet.begin(12)
            self.clock.now=106
            self.pet.tick()
            active=self.capture(key+'-timer')
            self.assertGreater(active.pixelColor(87,190).alpha(),0)
            self.clock.now=113
            self.pet.tick()
            self.assertEqual(self.pet.model.state,'finished')
            self.assertEqual(self.pet.finish_duration,SONG_SECONDS[key])
            self.assertTrue(self.pet.player.source().toLocalFile().endswith(key+'-complete.flac'))
            self.clock.now=115
            self.pet.tick()
            complete=self.capture(key+'-complete')
            self.assertEqual(self.pet.model.fade(self.clock()),0)
            self.assertEqual(complete.pixelColor(87,190).alpha(),0)
            self.clock.now=113+SONG_SECONDS[key]+1
            self.pet.tick()
            self.assertEqual(self.pet.player.playbackState(),QMediaPlayer.PlaybackState.StoppedState)

    def test_orbit_preserves_radius_and_full_loop(self):
        for fraction in [0,.25,.5,.75,1]:
            point=orbit(fraction)
            self.assertAlmostEqual(math.hypot(point.x()-190,point.y()-190),103)
        self.assertLess((orbit(1)-orbit(0)).manhattanLength(),1e-6)

    def test_real_qt_clock_pause_resume_completion(self):
        self.pet.clock=time.monotonic
        self.pet.started_at=time.monotonic()
        self.pet.last_reminder=self.pet.started_at
        self.pet.animation.start(16)
        self.pet.begin(1)
        QTest.qWait(250)
        self.pet.pause_resume()
        self.assertEqual(self.pet.model.state,'paused')
        paused=self.pet.model.remaining
        QTest.qWait(150)
        self.assertEqual(self.pet.model.remaining,paused)
        self.pet.pause_resume()
        QTest.qWait(950)
        self.assertEqual(self.pet.model.state,'finished')
        self.assertEqual(self.pet.model.remaining,0)

    def test_drag_and_empty_area_hit_testing(self):
        self.assertFalse(self.pet.interactive(QPointF(0,0)))
        self.assertTrue(self.pet.interactive(QPointF(180,180)))
        old=self.pet.pos()
        QTest.mousePress(self.pet,Qt.MouseButton.LeftButton,pos=QPoint(180,180))
        QTest.mouseMove(self.pet,QPoint(220,210))
        QTest.mouseRelease(self.pet,Qt.MouseButton.LeftButton,pos=QPoint(220,210))
        self.assertEqual(self.pet.pos(),old+QPoint(40,30))

    def test_settings_round_trip_and_invalid_data(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'settings.json'
            self.pet.settings_path=path
            self.pet.persist=True
            self.pet.character='hachiware'
            self.pet.sound=False
            self.pet.model.duration=3600
            self.pet.save_settings()
            self.pet.character='usagi'
            self.pet.model.duration=900
            pos=self.pet.load_settings()
            self.assertEqual(self.pet.character,'hachiware')
            self.assertEqual(self.pet.model.duration,3600)
            self.assertEqual(pos,[self.pet.x(),self.pet.y()])
            path.write_text('{"duration": "bad", "character": "unknown"}',encoding='utf-8')
            self.pet.load_settings()
            self.assertEqual(self.pet.model.duration,3600)
            self.pet.persist=False

    def test_qt_can_decode_and_play_all_completion_tracks(self):
        self.pet.audio.setVolume(0)
        for key,seconds in SONG_SECONDS.items():
            self.pet.audio_error_text=''
            self.pet.player.setSource(QUrl.fromLocalFile(str(ASSETS/f'{key}-complete.flac')))
            self.pet.player.play()
            for _ in range(100):
                QTest.qWait(20)
                if self.pet.player.duration() and self.pet.player.position()>0:
                    break
            self.assertEqual(self.pet.audio_error_text,'')
            self.assertAlmostEqual(self.pet.player.duration()/1000,seconds,delta=.05)
            self.assertGreater(self.pet.player.position(),0)
            self.pet.player.stop()


if __name__=='__main__':
    unittest.main(verbosity=2)
